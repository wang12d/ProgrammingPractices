#include <bits/stdc++.h>
#include "Toolbox.h"

using std::cout;
using std::endl;
using std::vector;
using std::accumulate;
using std::pair;
using std::unordered_map;
using ul = unsigned long;

const ul MOD = 1020202009;
const ul maxn = 24680+1;
const ul shilt = 1e5;

unordered_map<ul, ul> memo;

ul 
pot(ul n, ul m)
{
    ul res = 0;
    ul p = m;
    while (n / p) {
        res += n / p;
        p *= m;
    }
    return res;
}

ul
combinationMod(ul n, ul k, ul mod, vector<int>& primes)
{
    if (k > n) return 0;
    ul key = n*shilt+k;
    if (memo.count(key)) return memo[key];
    if (k == 0 || n == k) return memo[key] = 1;
    ul sz = primes.size();
    ul res = 1;
    for (ul i = 0; i < sz; ++i) {
        if (primes[i] > n) break;
        auto power = pot(n, primes[i]) - pot(n-k, primes[i]) - pot(k, primes[i]);
        res = res * Toolbox<ul>::powerWithMOD(primes[i], power, mod, 1) % mod;
    }
    return memo[key] = res;
}

int
main(int argc, char** argv)
{
    vector<ul> dp(maxn, 0);
    auto primes{Toolbox<int>::findPrimes(maxn)};
    dp[1] = 1;
    for (int i = 2; i < maxn; ++i) {
        auto prev = dp;
        memset(&dp.front(), 0, sizeof(ul)*dp.size());
        for (int k = i; k > 0; k -= 2) {
            int ub = i-k;
            for (int j = 0; j <= ub; j += 2)
            dp[k] = (dp[k] + prev[k+j-1] * combinationMod(k+j-1, j, MOD, primes) % MOD) % MOD;
        }
    }
    cout << accumulate(dp.begin(), dp.end(), 0) << endl;
}